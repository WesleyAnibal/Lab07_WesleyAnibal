package excecoes;

public class ValorInvalidoException extends PrecoInvalidoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValorInvalidoException(String msg) {
		super(msg);
	}

}
