package excecoes;

public class TrocaInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TrocaInvalidoException(String msg) {
		super(msg); 
	}

}
