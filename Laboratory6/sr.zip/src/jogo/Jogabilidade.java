package jogo;

public enum Jogabilidade {
	
	ONLINE, OFFLINE, MULTIPLAYER,COOPERATIVO, COMPETITIVO; 

}
